import { Router } from 'express';
import { DashboardService } from '@/services/dashboardService';
import { SearchService } from '@/services/searchService';
import { NotificationService } from '@/services/notificationService';
import { authenticateToken, AuthenticatedRequest } from '@/middleware/auth';
import { validateRequest, schemas } from '@/middleware/validation';

const router = Router();
const dashboardService = new DashboardService();
const searchService = new SearchService();
const notificationService = new NotificationService();

// GET /dashboard/stats
router.get(
  '/stats',
  authenticateToken,
  async (req: AuthenticatedRequest, res: any) => {
    try {
      const stats = await dashboardService.getDashboardStats(req.user!.id);

      res.json({
        success: true,
        data: stats
      });
    } catch (error: any) {
      res.status(error.statusCode || 500).json({
        success: false,
        error: {
          message: error.message,
          code: error.code
        }
      });
    }
  }
);

// GET /dashboard/search
router.get(
  '/search',
  authenticateToken,
  async (req: AuthenticatedRequest, res: any) => {
    try {
      const query = req.query.q as string;
      const type = req.query.type as string;
      const limit = parseInt(req.query.limit as string) || 20;

      const filters: any = {};
      if (type) filters.type = type.split(',');
      if (req.query.dateStart && req.query.dateEnd) {
        filters.dateRange = {
          start: req.query.dateStart as string,
          end: req.query.dateEnd as string
        };
      }

      const results = await searchService.search(req.user!.id, query, filters, limit);

      res.json({
        success: true,
        data: results
      });
    } catch (error: any) {
      res.status(error.statusCode || 500).json({
        success: false,
        error: {
          message: error.message,
          code: error.code
        }
      });
    }
  }
);

// GET /dashboard/search/suggestions
router.get(
  '/search/suggestions',
  authenticateToken,
  async (req: AuthenticatedRequest, res: any) => {
    try {
      const query = req.query.q as string;
      const suggestions = await searchService.getSearchSuggestions(req.user!.id, query);

      res.json({
        success: true,
        data: suggestions
      });
    } catch (error: any) {
      res.status(error.statusCode || 500).json({
        success: false,
        error: {
          message: error.message,
          code: error.code
        }
      });
    }
  }
);

// GET /dashboard/notifications
router.get(
  '/notifications',
  authenticateToken,
  async (req: AuthenticatedRequest, res: any) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const unreadOnly = req.query.unreadOnly === 'true';

      const notifications = await notificationService.getUserNotifications(
        req.user!.id,
        limit,
        unreadOnly
      );

      res.json({
        success: true,
        data: notifications
      });
    } catch (error: any) {
      res.status(error.statusCode || 500).json({
        success: false,
        error: {
          message: error.message,
          code: error.code
        }
      });
    }
  }
);

// PUT /dashboard/notifications/:id/read
router.put(
  '/notifications/:id/read',
  authenticateToken,
  async (req: AuthenticatedRequest, res: any) => {
    try {
      await notificationService.markAsRead(req.user!.id, req.params.id);

      res.json({
        success: true,
        data: { message: 'Notification marked as read' }
      });
    } catch (error: any) {
      res.status(error.statusCode || 500).json({
        success: false,
        error: {
          message: error.message,
          code: error.code
        }
      });
    }
  }
);

// PUT /dashboard/notifications/read-all
router.put(
  '/notifications/read-all',
  authenticateToken,
  async (req: AuthenticatedRequest, res: any) => {
    try {
      await notificationService.markAllAsRead(req.user!.id);

      res.json({
        success: true,
        data: { message: 'All notifications marked as read' }
      });
    } catch (error: any) {
      res.status(error.statusCode || 500).json({
        success: false,
        error: {
          message: error.message,
          code: error.code
        }
      });
    }
  }
);

// GET /dashboard/notifications/unread-count
router.get(
  '/notifications/unread-count',
  authenticateToken,
  async (req: AuthenticatedRequest, res: any) => {
    try {
      const count = await notificationService.getUnreadCount(req.user!.id);

      res.json({
        success: true,
        data: { count }
      });
    } catch (error: any) {
      res.status(error.statusCode || 500).json({
        success: false,
        error: {
          message: error.message,
          code: error.code
        }
      });
    }
  }
);

export default router;