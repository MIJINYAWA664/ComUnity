import { Request, Response, NextFunction } from 'express';
import { authenticateToken, AuthenticatedRequest } from '@/middleware/auth';
import jwt from 'jsonwebtoken';
import { supabase } from '@/config/supabase';

jest.mock('jsonwebtoken');
jest.mock('@/config/supabase');

describe('Auth Middleware', () => {
  let req: Partial<AuthenticatedRequest>;
  let res: Partial<Response>;
  let next: NextFunction;
  const mockJwt = jwt as jest.Mocked<typeof jwt>;

  beforeEach(() => {
    req = {
      headers: {},
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };
    next = jest.fn();
  });

  describe('authenticateToken', () => {
    it('should authenticate valid token', async () => {
      req.headers = {
        authorization: 'Bearer valid-token',
      };

      mockJwt.verify.mockReturnValue({
        userId: 'user-123',
        email: 'test@example.com',
      } as never);

      (supabase.from as jest.Mock).mockReturnValue({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: {
            id: 'user-123',
            email: 'test@example.com',
            is_active: true,
          },
          error: null,
        }),
      });

      await authenticateToken(req as AuthenticatedRequest, res as Response, next);

      expect(req.user).toEqual({
        id: 'user-123',
        email: 'test@example.com',
      });
      expect(next).toHaveBeenCalled();
    });

    it('should reject missing token', async () => {
      await authenticateToken(req as AuthenticatedRequest, res as Response, next);

      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        error: {
          message: 'Access token required',
          code: 'MISSING_TOKEN',
        },
      });
      expect(next).not.toHaveBeenCalled();
    });

    it('should reject invalid token', async () => {
      req.headers = {
        authorization: 'Bearer invalid-token',
      };

      mockJwt.verify.mockImplementation(() => {
        throw new jwt.JsonWebTokenError('Invalid token');
      });

      await authenticateToken(req as AuthenticatedRequest, res as Response, next);

      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        error: {
          message: 'Invalid token',
          code: 'INVALID_TOKEN',
        },
      });
      expect(next).not.toHaveBeenCalled();
    });
  });
});