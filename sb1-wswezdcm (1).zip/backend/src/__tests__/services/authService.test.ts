import { AuthService } from '@/services/authService';
import { supabase, supabaseAdmin } from '@/config/supabase';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

// Mock dependencies
jest.mock('bcryptjs');
jest.mock('jsonwebtoken');

describe('AuthService', () => {
  let authService: AuthService;
  const mockBcrypt = bcrypt as jest.Mocked<typeof bcrypt>;
  const mockJwt = jwt as jest.Mocked<typeof jwt>;

  beforeEach(() => {
    authService = new AuthService();
    process.env.JWT_SECRET = 'test-secret';
  });

  describe('signup', () => {
    const signupData = {
      email: 'test@example.com',
      password: 'TestPass123',
      firstName: 'John',
      lastName: 'Doe',
    };

    it('should create a new user successfully', async () => {
      // Mock implementations
      (supabase.from as jest.Mock).mockReturnValue({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({ data: null, error: null }),
      });

      mockBcrypt.hash.mockResolvedValue('hashed-password' as never);

      (supabaseAdmin.auth.admin.createUser as jest.Mock).mockResolvedValue({
        data: { user: { id: 'user-123' } },
        error: null,
      });

      (supabase.from as jest.Mock).mockReturnValue({
        insert: jest.fn().mockReturnThis(),
        select: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: {
            id: 'user-123',
            email: 'test@example.com',
            first_name: 'John',
            last_name: 'Doe',
            accessibility_settings: {},
            emergency_contacts: [],
            preferred_language: 'en',
            sign_language_preference: 'asl',
            email_verified: false,
          },
          error: null,
        }),
      });

      mockJwt.sign.mockReturnValue('mock-token' as never);

      const result = await authService.signup(signupData);

      expect(result).toHaveProperty('user');
      expect(result).toHaveProperty('accessToken');
      expect(result).toHaveProperty('refreshToken');
      expect(result.user.email).toBe(signupData.email);
      expect(result.user.firstName).toBe(signupData.firstName);
    });

    it('should throw error if user already exists', async () => {
      (supabase.from as jest.Mock).mockReturnValue({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: { id: 'existing-user' },
          error: null,
        }),
      });

      await expect(authService.signup(signupData)).rejects.toThrow('User already exists');
    });
  });

  describe('login', () => {
    const loginData = {
      email: 'test@example.com',
      password: 'TestPass123',
    };

    it('should login user successfully', async () => {
      (supabase.auth.signInWithPassword as jest.Mock).mockResolvedValue({
        data: { user: { id: 'user-123' } },
        error: null,
      });

      (supabase.from as jest.Mock).mockReturnValue({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: {
            id: 'user-123',
            email: 'test@example.com',
            first_name: 'John',
            last_name: 'Doe',
            is_active: true,
            accessibility_settings: {},
            emergency_contacts: [],
            preferred_language: 'en',
            sign_language_preference: 'asl',
            email_verified: true,
          },
          error: null,
        }),
      });

      mockJwt.sign.mockReturnValue('mock-token' as never);

      const result = await authService.login(loginData);

      expect(result).toHaveProperty('user');
      expect(result).toHaveProperty('accessToken');
      expect(result.user.email).toBe(loginData.email);
    });

    it('should throw error for invalid credentials', async () => {
      (supabase.auth.signInWithPassword as jest.Mock).mockResolvedValue({
        data: { user: null },
        error: { message: 'Invalid credentials' },
      });

      await expect(authService.login(loginData)).rejects.toThrow('Invalid email or password');
    });
  });

  describe('refreshToken', () => {
    it('should generate new access token', async () => {
      const refreshToken = 'valid-refresh-token';
      
      mockJwt.verify.mockReturnValue({
        userId: 'user-123',
        email: 'test@example.com',
        type: 'refresh',
      } as never);

      (supabase.from as jest.Mock).mockReturnValue({
        select: jest.fn().mockReturnThis(),
        eq: jest.fn().mockReturnThis(),
        single: jest.fn().mockResolvedValue({
          data: {
            id: 'user-123',
            email: 'test@example.com',
            is_active: true,
          },
          error: null,
        }),
      });

      mockJwt.sign.mockReturnValue('new-access-token' as never);

      const result = await authService.refreshToken(refreshToken);

      expect(result).toHaveProperty('accessToken');
      expect(result).toHaveProperty('expiresIn');
    });

    it('should throw error for invalid refresh token', async () => {
      mockJwt.verify.mockImplementation(() => {
        throw new Error('Invalid token');
      });

      await expect(authService.refreshToken('invalid-token')).rejects.toThrow('Invalid refresh token');
    });
  });
});