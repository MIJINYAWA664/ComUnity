import { supabase } from '@/config/supabase';
import { createError } from '@/middleware/errorHandler';

export interface Notification {
  id: string;
  userId: string;
  type: 'message' | 'lesson' | 'emergency' | 'system' | 'achievement';
  title: string;
  message: string;
  data: Record<string, any>;
  isRead: boolean;
  createdAt: string;
  expiresAt?: string;
}

export interface NotificationPreferences {
  email: boolean;
  push: boolean;
  inApp: boolean;
  types: {
    messages: boolean;
    lessons: boolean;
    emergency: boolean;
    system: boolean;
    achievements: boolean;
  };
}

export class NotificationService {
  async createNotification(
    userId: string,
    type: Notification['type'],
    title: string,
    message: string,
    data: Record<string, any> = {},
    expiresAt?: Date
  ): Promise<Notification> {
    try {
      // For now, we'll store notifications in a simple table structure
      // In production, you might use a dedicated notification service
      
      const notificationData = {
        user_id: userId,
        type,
        title,
        message,
        data,
        is_read: false,
        created_at: new Date().toISOString(),
        expires_at: expiresAt?.toISOString()
      };

      // Store in messages table with special metadata for notifications
      const { data, error } = await supabase
        .from('messages')
        .insert({
          sender_id: userId,
          conversation_id: '00000000-0000-0000-0000-000000000000', // System conversation
          content: message,
          message_type: 'text',
          metadata: {
            notification: true,
            notification_type: type,
            notification_title: title,
            notification_data: data,
            is_read: false,
            expires_at: expiresAt?.toISOString()
          }
        })
        .select()
        .single();

      if (error) {
        throw createError('Failed to create notification', 500, 'NOTIFICATION_CREATE_ERROR', error);
      }

      return {
        id: data.id,
        userId: data.sender_id,
        type,
        title,
        message,
        data,
        isRead: false,
        createdAt: data.created_at,
        expiresAt: expiresAt?.toISOString()
      };
    } catch (error: any) {
      throw createError('Failed to create notification', 500, 'NOTIFICATION_ERROR', error);
    }
  }

  async getUserNotifications(
    userId: string,
    limit: number = 50,
    unreadOnly: boolean = false
  ): Promise<Notification[]> {
    try {
      let queryBuilder = supabase
        .from('messages')
        .select('*')
        .eq('sender_id', userId)
        .eq('conversation_id', '00000000-0000-0000-0000-000000000000')
        .not('metadata->>notification', 'is', null);

      if (unreadOnly) {
        queryBuilder = queryBuilder.eq('metadata->>is_read', 'false');
      }

      const { data, error } = await queryBuilder
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) {
        throw createError('Failed to fetch notifications', 500, 'NOTIFICATION_FETCH_ERROR', error);
      }

      return data.map(item => ({
        id: item.id,
        userId: item.sender_id,
        type: item.metadata.notification_type,
        title: item.metadata.notification_title,
        message: item.content,
        data: item.metadata.notification_data || {},
        isRead: item.metadata.is_read === 'true',
        createdAt: item.created_at,
        expiresAt: item.metadata.expires_at
      }));
    } catch (error: any) {
      throw createError('Failed to fetch notifications', 500, 'NOTIFICATION_ERROR', error);
    }
  }

  async markAsRead(userId: string, notificationId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('messages')
        .update({
          metadata: supabase.rpc('jsonb_set', {
            target: supabase.raw('metadata'),
            path: '{is_read}',
            new_value: '"true"'
          })
        })
        .eq('id', notificationId)
        .eq('sender_id', userId);

      if (error) {
        throw createError('Failed to mark notification as read', 500, 'NOTIFICATION_UPDATE_ERROR', error);
      }
    } catch (error: any) {
      throw createError('Failed to update notification', 500, 'NOTIFICATION_ERROR', error);
    }
  }

  async markAllAsRead(userId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('messages')
        .update({
          metadata: supabase.rpc('jsonb_set', {
            target: supabase.raw('metadata'),
            path: '{is_read}',
            new_value: '"true"'
          })
        })
        .eq('sender_id', userId)
        .eq('conversation_id', '00000000-0000-0000-0000-000000000000')
        .eq('metadata->>is_read', 'false');

      if (error) {
        throw createError('Failed to mark all notifications as read', 500, 'NOTIFICATION_UPDATE_ERROR', error);
      }
    } catch (error: any) {
      throw createError('Failed to update notifications', 500, 'NOTIFICATION_ERROR', error);
    }
  }

  async deleteNotification(userId: string, notificationId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('messages')
        .delete()
        .eq('id', notificationId)
        .eq('sender_id', userId)
        .eq('conversation_id', '00000000-0000-0000-0000-000000000000');

      if (error) {
        throw createError('Failed to delete notification', 500, 'NOTIFICATION_DELETE_ERROR', error);
      }
    } catch (error: any) {
      throw createError('Failed to delete notification', 500, 'NOTIFICATION_ERROR', error);
    }
  }

  async getUnreadCount(userId: string): Promise<number> {
    try {
      const { count, error } = await supabase
        .from('messages')
        .select('*', { count: 'exact', head: true })
        .eq('sender_id', userId)
        .eq('conversation_id', '00000000-0000-0000-0000-000000000000')
        .eq('metadata->>is_read', 'false');

      if (error) {
        throw createError('Failed to get unread count', 500, 'NOTIFICATION_COUNT_ERROR', error);
      }

      return count || 0;
    } catch (error: any) {
      throw createError('Failed to get unread count', 500, 'NOTIFICATION_ERROR', error);
    }
  }

  // Helper methods for specific notification types
  async notifyNewMessage(userId: string, senderName: string, messagePreview: string): Promise<void> {
    await this.createNotification(
      userId,
      'message',
      'New Message',
      `${senderName}: ${messagePreview}`,
      { senderName, messagePreview }
    );
  }

  async notifyLessonCompleted(userId: string, lessonTitle: string): Promise<void> {
    await this.createNotification(
      userId,
      'achievement',
      'Lesson Completed!',
      `Congratulations! You completed "${lessonTitle}"`,
      { lessonTitle, type: 'lesson_completed' }
    );
  }

  async notifyEmergencyAlert(userId: string, alertType: string, location?: string): Promise<void> {
    await this.createNotification(
      userId,
      'emergency',
      'Emergency Alert',
      `Emergency assistance requested: ${alertType}`,
      { alertType, location },
      new Date(Date.now() + 24 * 60 * 60 * 1000) // Expires in 24 hours
    );
  }

  async notifySystemUpdate(userId: string, updateInfo: string): Promise<void> {
    await this.createNotification(
      userId,
      'system',
      'System Update',
      updateInfo,
      { type: 'system_update' },
      new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // Expires in 7 days
    );
  }
}