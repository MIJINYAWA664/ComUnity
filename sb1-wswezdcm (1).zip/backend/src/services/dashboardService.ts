import { supabase } from '@/config/supabase';
import { createError } from '@/middleware/errorHandler';

export interface DashboardStats {
  totalMessages: number;
  totalConversations: number;
  learningProgress: number;
  recognitionSessions: number;
  recentActivity: Array<{
    id: string;
    type: 'message' | 'lesson' | 'recognition';
    title: string;
    timestamp: string;
  }>;
  weeklyActivity: Array<{
    date: string;
    messages: number;
    lessons: number;
    recognition: number;
  }>;
}

export class DashboardService {
  async getDashboardStats(userId: string): Promise<DashboardStats> {
    try {
      // Get total messages
      const { count: totalMessages } = await supabase
        .from('messages')
        .select('*', { count: 'exact', head: true })
        .eq('sender_id', userId);

      // Get total conversations
      const { count: totalConversations } = await supabase
        .from('conversation_participants')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('is_active', true);

      // Get learning progress
      const { data: progressData } = await supabase
        .from('user_lesson_progress')
        .select('progress_percentage')
        .eq('user_id', userId);

      const learningProgress = progressData?.length 
        ? Math.round(progressData.reduce((acc, p) => acc + p.progress_percentage, 0) / progressData.length)
        : 0;

      // Get recognition sessions
      const { count: recognitionSessions } = await supabase
        .from('sign_recognition_sessions')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId);

      // Get recent activity
      const recentActivity = await this.getRecentActivity(userId);

      // Get weekly activity
      const weeklyActivity = await this.getWeeklyActivity(userId);

      return {
        totalMessages: totalMessages || 0,
        totalConversations: totalConversations || 0,
        learningProgress,
        recognitionSessions: recognitionSessions || 0,
        recentActivity,
        weeklyActivity
      };
    } catch (error: any) {
      throw createError('Failed to fetch dashboard stats', 500, 'DASHBOARD_ERROR', error);
    }
  }

  private async getRecentActivity(userId: string): Promise<DashboardStats['recentActivity']> {
    const activities: DashboardStats['recentActivity'] = [];

    // Recent messages
    const { data: messages } = await supabase
      .from('messages')
      .select('id, content, created_at')
      .eq('sender_id', userId)
      .order('created_at', { ascending: false })
      .limit(5);

    messages?.forEach(msg => {
      activities.push({
        id: msg.id,
        type: 'message',
        title: `Message: ${msg.content.substring(0, 50)}...`,
        timestamp: msg.created_at
      });
    });

    // Recent lesson progress
    const { data: lessons } = await supabase
      .from('user_lesson_progress')
      .select(`
        id,
        last_accessed,
        learning_lessons(title)
      `)
      .eq('user_id', userId)
      .order('last_accessed', { ascending: false })
      .limit(5);

    lessons?.forEach(lesson => {
      activities.push({
        id: lesson.id,
        type: 'lesson',
        title: `Lesson: ${(lesson as any).learning_lessons.title}`,
        timestamp: lesson.last_accessed
      });
    });

    // Recent recognition sessions
    const { data: sessions } = await supabase
      .from('sign_recognition_sessions')
      .select('id, session_start, total_gestures')
      .eq('user_id', userId)
      .order('session_start', { ascending: false })
      .limit(5);

    sessions?.forEach(session => {
      activities.push({
        id: session.id,
        type: 'recognition',
        title: `Recognition: ${session.total_gestures} gestures`,
        timestamp: session.session_start
      });
    });

    // Sort by timestamp and return top 10
    return activities
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);
  }

  private async getWeeklyActivity(userId: string): Promise<DashboardStats['weeklyActivity']> {
    const weeklyData: DashboardStats['weeklyActivity'] = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      // Count messages for this date
      const { count: messages } = await supabase
        .from('messages')
        .select('*', { count: 'exact', head: true })
        .eq('sender_id', userId)
        .gte('created_at', `${dateStr}T00:00:00.000Z`)
        .lt('created_at', `${dateStr}T23:59:59.999Z`);

      // Count lesson activities for this date
      const { count: lessons } = await supabase
        .from('user_lesson_progress')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .gte('last_accessed', `${dateStr}T00:00:00.000Z`)
        .lt('last_accessed', `${dateStr}T23:59:59.999Z`);

      // Count recognition sessions for this date
      const { count: recognition } = await supabase
        .from('sign_recognition_sessions')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .gte('session_start', `${dateStr}T00:00:00.000Z`)
        .lt('session_start', `${dateStr}T23:59:59.999Z`);

      weeklyData.push({
        date: dateStr,
        messages: messages || 0,
        lessons: lessons || 0,
        recognition: recognition || 0
      });
    }

    return weeklyData;
  }
}