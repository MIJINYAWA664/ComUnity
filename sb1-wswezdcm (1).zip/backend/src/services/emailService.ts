import { supabaseAdmin } from '@/config/supabase';
import { createError } from '@/middleware/errorHandler';

export class EmailService {
  async sendVerificationEmail(email: string, token: string): Promise<void> {
    try {
      // In production, integrate with email service (SendGrid, AWS SES, etc.)
      const verificationUrl = `${process.env.FRONTEND_URL}/verify-email?token=${token}`;
      
      // For now, we'll use Supabase's built-in email verification
      const { error } = await supabaseAdmin.auth.admin.generateLink({
        type: 'signup',
        email,
        options: {
          redirectTo: `${process.env.FRONTEND_URL}/auth/callback`
        }
      });

      if (error) {
        throw createError('Failed to send verification email', 500, 'EMAIL_SEND_ERROR', error);
      }
    } catch (error: any) {
      console.error('Email service error:', error);
      throw error;
    }
  }

  async sendPasswordResetEmail(email: string): Promise<void> {
    try {
      const { error } = await supabaseAdmin.auth.admin.generateLink({
        type: 'recovery',
        email,
        options: {
          redirectTo: `${process.env.FRONTEND_URL}/reset-password`
        }
      });

      if (error) {
        throw createError('Failed to send password reset email', 500, 'EMAIL_SEND_ERROR', error);
      }
    } catch (error: any) {
      console.error('Password reset email error:', error);
      throw error;
    }
  }
}