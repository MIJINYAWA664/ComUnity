import { supabase } from '@/config/supabase';
import { createError } from '@/middleware/errorHandler';

export interface SearchResult {
  id: string;
  type: 'user' | 'message' | 'lesson' | 'conversation';
  title: string;
  description: string;
  metadata: Record<string, any>;
  relevanceScore: number;
}

export interface SearchFilters {
  type?: string[];
  dateRange?: {
    start: string;
    end: string;
  };
  difficulty?: string[];
  category?: string[];
}

export class SearchService {
  async search(
    userId: string,
    query: string,
    filters: SearchFilters = {},
    limit: number = 20
  ): Promise<SearchResult[]> {
    if (!query || query.trim().length < 2) {
      throw createError('Search query must be at least 2 characters', 400, 'INVALID_QUERY');
    }

    const results: SearchResult[] = [];
    const searchTerm = query.trim().toLowerCase();

    try {
      // Search users (if type not filtered or includes 'user')
      if (!filters.type || filters.type.includes('user')) {
        const userResults = await this.searchUsers(searchTerm, limit);
        results.push(...userResults);
      }

      // Search messages (if type not filtered or includes 'message')
      if (!filters.type || filters.type.includes('message')) {
        const messageResults = await this.searchMessages(userId, searchTerm, filters, limit);
        results.push(...messageResults);
      }

      // Search lessons (if type not filtered or includes 'lesson')
      if (!filters.type || filters.type.includes('lesson')) {
        const lessonResults = await this.searchLessons(searchTerm, filters, limit);
        results.push(...lessonResults);
      }

      // Search conversations (if type not filtered or includes 'conversation')
      if (!filters.type || filters.type.includes('conversation')) {
        const conversationResults = await this.searchConversations(userId, searchTerm, limit);
        results.push(...conversationResults);
      }

      // Sort by relevance score and limit results
      return results
        .sort((a, b) => b.relevanceScore - a.relevanceScore)
        .slice(0, limit);

    } catch (error: any) {
      throw createError('Search failed', 500, 'SEARCH_ERROR', error);
    }
  }

  private async searchUsers(query: string, limit: number): Promise<SearchResult[]> {
    const { data, error } = await supabase
      .from('users')
      .select('id, first_name, last_name, profile_picture_url, preferred_language')
      .or(`first_name.ilike.%${query}%,last_name.ilike.%${query}%`)
      .eq('is_active', true)
      .limit(limit);

    if (error) return [];

    return data.map(user => ({
      id: user.id,
      type: 'user' as const,
      title: `${user.first_name} ${user.last_name}`,
      description: `User - ${user.preferred_language}`,
      metadata: {
        profilePictureUrl: user.profile_picture_url,
        preferredLanguage: user.preferred_language
      },
      relevanceScore: this.calculateRelevanceScore(query, `${user.first_name} ${user.last_name}`)
    }));
  }

  private async searchMessages(
    userId: string,
    query: string,
    filters: SearchFilters,
    limit: number
  ): Promise<SearchResult[]> {
    let queryBuilder = supabase
      .from('messages')
      .select(`
        id,
        content,
        message_type,
        created_at,
        conversations(name, type)
      `)
      .eq('sender_id', userId)
      .ilike('content', `%${query}%`);

    // Apply date range filter
    if (filters.dateRange) {
      queryBuilder = queryBuilder
        .gte('created_at', filters.dateRange.start)
        .lte('created_at', filters.dateRange.end);
    }

    const { data, error } = await queryBuilder
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) return [];

    return data.map(message => ({
      id: message.id,
      type: 'message' as const,
      title: `Message: ${message.content.substring(0, 50)}...`,
      description: `${message.message_type} message from ${new Date(message.created_at).toLocaleDateString()}`,
      metadata: {
        messageType: message.message_type,
        conversationName: (message as any).conversations?.name,
        conversationType: (message as any).conversations?.type,
        createdAt: message.created_at
      },
      relevanceScore: this.calculateRelevanceScore(query, message.content)
    }));
  }

  private async searchLessons(
    query: string,
    filters: SearchFilters,
    limit: number
  ): Promise<SearchResult[]> {
    let queryBuilder = supabase
      .from('learning_lessons')
      .select(`
        id,
        title,
        description,
        difficulty_level,
        estimated_duration,
        learning_categories(name)
      `)
      .or(`title.ilike.%${query}%,description.ilike.%${query}%`)
      .eq('is_published', true);

    // Apply difficulty filter
    if (filters.difficulty && filters.difficulty.length > 0) {
      queryBuilder = queryBuilder.in('difficulty_level', filters.difficulty);
    }

    // Apply category filter
    if (filters.category && filters.category.length > 0) {
      queryBuilder = queryBuilder.in('learning_categories.name', filters.category);
    }

    const { data, error } = await queryBuilder
      .order('sort_order', { ascending: true })
      .limit(limit);

    if (error) return [];

    return data.map(lesson => ({
      id: lesson.id,
      type: 'lesson' as const,
      title: lesson.title,
      description: lesson.description || '',
      metadata: {
        difficultyLevel: lesson.difficulty_level,
        estimatedDuration: lesson.estimated_duration,
        category: (lesson as any).learning_categories?.name
      },
      relevanceScore: this.calculateRelevanceScore(query, `${lesson.title} ${lesson.description}`)
    }));
  }

  private async searchConversations(
    userId: string,
    query: string,
    limit: number
  ): Promise<SearchResult[]> {
    const { data, error } = await supabase
      .from('conversations')
      .select(`
        id,
        name,
        type,
        description,
        created_at,
        conversation_participants!inner(user_id)
      `)
      .eq('conversation_participants.user_id', userId)
      .eq('conversation_participants.is_active', true)
      .or(`name.ilike.%${query}%,description.ilike.%${query}%`)
      .eq('is_active', true)
      .limit(limit);

    if (error) return [];

    return data.map(conversation => ({
      id: conversation.id,
      type: 'conversation' as const,
      title: conversation.name || `${conversation.type} conversation`,
      description: conversation.description || `${conversation.type} conversation`,
      metadata: {
        conversationType: conversation.type,
        createdAt: conversation.created_at
      },
      relevanceScore: this.calculateRelevanceScore(query, `${conversation.name} ${conversation.description}`)
    }));
  }

  private calculateRelevanceScore(query: string, text: string): number {
    if (!text) return 0;
    
    const queryLower = query.toLowerCase();
    const textLower = text.toLowerCase();
    
    // Exact match gets highest score
    if (textLower.includes(queryLower)) {
      const position = textLower.indexOf(queryLower);
      // Earlier matches get higher scores
      return 1.0 - (position / text.length) * 0.5;
    }
    
    // Partial word matches
    const queryWords = queryLower.split(' ');
    const textWords = textLower.split(' ');
    let matchCount = 0;
    
    queryWords.forEach(queryWord => {
      textWords.forEach(textWord => {
        if (textWord.includes(queryWord) || queryWord.includes(textWord)) {
          matchCount++;
        }
      });
    });
    
    return matchCount / (queryWords.length + textWords.length);
  }

  async getSearchSuggestions(userId: string, query: string): Promise<string[]> {
    if (!query || query.length < 2) return [];

    try {
      // Get recent search terms from user's messages
      const { data: messages } = await supabase
        .from('messages')
        .select('content')
        .eq('sender_id', userId)
        .ilike('content', `%${query}%`)
        .order('created_at', { ascending: false })
        .limit(10);

      // Get lesson titles that match
      const { data: lessons } = await supabase
        .from('learning_lessons')
        .select('title')
        .ilike('title', `%${query}%`)
        .eq('is_published', true)
        .limit(5);

      const suggestions = new Set<string>();

      // Extract relevant terms from messages
      messages?.forEach(msg => {
        const words = msg.content.toLowerCase().split(' ');
        words.forEach(word => {
          if (word.includes(query.toLowerCase()) && word.length > 2) {
            suggestions.add(word);
          }
        });
      });

      // Add lesson titles
      lessons?.forEach(lesson => {
        if (lesson.title.toLowerCase().includes(query.toLowerCase())) {
          suggestions.add(lesson.title);
        }
      });

      return Array.from(suggestions).slice(0, 8);
    } catch (error) {
      return [];
    }
  }
}