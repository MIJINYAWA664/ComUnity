#!/bin/bash

set -e

# Configuration
APP_NAME="community-backend"
DOCKER_IMAGE="$APP_NAME:latest"
CONTAINER_NAME="$APP_NAME-container"

echo "🚀 Starting deployment of $APP_NAME..."

# Build the Docker image
echo "📦 Building Docker image..."
docker build -t $DOCKER_IMAGE .

# Stop and remove existing container
echo "🛑 Stopping existing container..."
docker stop $CONTAINER_NAME 2>/dev/null || true
docker rm $CONTAINER_NAME 2>/dev/null || true

# Run database migrations
echo "🗄️ Running database migrations..."
# Add migration commands here if needed

# Start new container
echo "🏃 Starting new container..."
docker run -d \
  --name $CONTAINER_NAME \
  --restart unless-stopped \
  -p 3001:3001 \
  --env-file .env.production \
  $DOCKER_IMAGE

# Health check
echo "🏥 Performing health check..."
sleep 10

for i in {1..30}; do
  if curl -f http://localhost:3001/health > /dev/null 2>&1; then
    echo "✅ Health check passed!"
    break
  fi
  
  if [ $i -eq 30 ]; then
    echo "❌ Health check failed after 30 attempts"
    docker logs $CONTAINER_NAME
    exit 1
  fi
  
  echo "⏳ Waiting for application to start... ($i/30)"
  sleep 2
done

# Cleanup old images
echo "🧹 Cleaning up old images..."
docker image prune -f

echo "🎉 Deployment completed successfully!"
echo "📊 Application is running at http://localhost:3001"
echo "📈 Health check: http://localhost:3001/health"